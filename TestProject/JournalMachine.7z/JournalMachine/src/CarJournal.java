import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class CarJournal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите количество машин:");
        int numOfCars = scanner.nextInt();
        Car[] cars = new Car[numOfCars];
        for (int i = 0; i < numOfCars; i++) {
            System.out.println("Введите марку машины " + (i+1) + ":");
            String brand = scanner.next();
            System.out.println("Введите модель машины " + (i+1) + ":");
            String model = scanner.next();
            System.out.println("Введите год выпуска машины " + (i+1) + ":");
            int year = scanner.nextInt();
            System.out.println("Введите Имя владельца машины " + (i+1) + ":");
            String name = scanner.next();
            cars[i] = new Car(brand, model, year,name);
        }
        System.out.println("Журнал машин:");
        for (int i = 0; i < numOfCars; i++) {
            System.out.println((i+1) + ". " + cars[i]);
        }
    }
}

class Car {
    private String brand;
    private String model;
    private int year;
    private String name;

    Date date = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

    public Car(String brand, String model, int year, String name) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.name=name;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return brand + " " + model + " (" + year + ")"+"- "+name + " " + formatter.format(date);
    }
}
